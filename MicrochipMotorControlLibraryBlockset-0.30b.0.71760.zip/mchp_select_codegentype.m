function mchp_select_codegentype
blk = gcb;
choice = getparamcode(blk);
cgblock = [blk '/codegeneration'];

simblkpath = get_param(cgblock, 'ReferenceBlock');
[blockgroup, existing_blocktype] = splitlast(simblkpath, ':');
if ~strcmp(choice,existing_blocktype)
    newblkpath = [blockgroup ':' choice];
    pos = get_param(cgblock,'Position');
    delete_block(cgblock);
    add_block(newblkpath,cgblock,'Position',pos);
    delegateparameters(cgblock, blk);
end
%endfunction

function [pre,post] = splitlast(s, sep)
% split on last occurrence of separator (expects single-char separator)
i = strfind(s,sep);
if isempty(i)
    pre = s;
    post = '';
else
    i = i(end);
    pre = s(1:i-1);
    post = s(i+1:end);
end
%endfunction

function [dpnames, dps] = getDialogParams(blk)
dps = get_param(blk,'DialogParameters');
if isempty(dps)
    dps = struct;
end
dpnames = fieldnames(dps);
%endfunction

function delegateparameters(blk, parent)
% delegate lower-level parameters from main block
% do this for all dialog parameters of type "string"
% which are present in both parent and child
[ppnames, pparams] = getDialogParams(parent);
[cpnames, cparams] = getDialogParams(blk);
for i = 1:length(cpnames)
    cpname = cpnames{i};
    % effect = 'none';
    if isfield(pparams, cpname)
        param = cparams.(cpname);
        % effect = 'present';
        if strcmp(param.Type, 'string')
            set_param(blk, cpname, cpname);
            % effect = 'changed';
            % This sets the value of the named parameter to its own name,
            % thus referring to the parent value.
        end
    end
    % disp(sprintf('%s: %s', cpname, effect));
end
%endfunction

function [code,k] = getparamcode(blk)
% hack to get around the stupid lack of raw value + display value
% decoupling in Simulink popup mask parameters
mask = Simulink.Mask.get(blk);
displayvalue = get_param(blk, 'cgentype');
k = findfirstmatch(displayvalue, mask.getParameter('cgentype').TypeOptions);
code = mask.getParameter('cgentype2').TypeOptions{k};
%endfunction

function index = findfirstmatch(item, list)
for i = 1:length(list)
    if strcmp(item,list{i})
        index = i;
        return;
    end
end
index = -1;
%endfunction