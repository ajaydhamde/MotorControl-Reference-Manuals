classdef Timer < rtw.connectivity.Timer
    % TIMER is a Timer subclass to get timing information for the application
    %
    %   See also RTW.CONNECTIVITY.TIMER

    %   Copyright 2009-2011 The MathWorks, Inc.
    % Updated for Microchip microcontrollers

    methods

        function this = Timer

            % Configure data type returned by timer reads
            this.setTimerDataType('uint32');

            % Timer Scaling
            ticksPerSecond = inv(mchp.prefs.getPIL_TimerResolution);    %inv(4.267e-6);
            if ticksPerSecond == -1 %% With Matlab R2013b, this is required, even if we are not using a timer.
                disp('Warning: No Timer set to measure time within the PIL simulation. Add the PIL Profiling block which is in the Profiling library folder.');
                this.setTicksPerSecond(1);
                this.setCountDirection('up');
                readTimerExpression = '0';
                this.setReadTimerExpression(readTimerExpression);
            else
                this.setTicksPerSecond(ticksPerSecond);

                % The timer counts upwards
                this.setCountDirection('up');

                %% Configure source files required to access the timer
                %% MCHP_blks = which('MCHP_dsPIC_stf.tlc');    % Get MCHP blockset
                %% MCHP_blks_root = fileparts(fileparts(MCHP_blks));
                %% headerFile = fullfile(MCHP_blks_root,'blocks','src','MCHP_ProfileTimer.h');
                %            headerFile = 'MCHP_TIMER_PIL_Profiling.h';  % This file must be created with the block PIL Profiling

              %  timerSourceFile = '';	% require empty char for older matlab release. Otherwise, default [] cause error
                %headerFile = 'xc.h';
                % We need to provide the full path to xc.h for file beeing added in compiler repport.
                % as we do not know which compiler is used, we take the most recent xc32 compiler.
                % in source code, only the file xc.h is beeing added ; no full path thus the xc.h file related to current compiler is used.
                [a b c d] = MCHP_findCompilerPath('c32','');
                headerFile = fullfile(b{1},'pic32mx','include','xc.h');
                if ~exist(headerFile,'file')
                    disp(['Warning: PIL Timer require file xc.h. Not found at ' headerFile]);
                end
                % timerSourceFile = fullfile(Stm32RootPath,...
                % 'pil',...
                % 'stm32F4xxSerialRtiostream',...
                % 'STM32F4xxSerialRtiostream-ProfilerTimer.c');

               % this.setSourceFile(timerSourceFile);
                this.setHeaderFile(headerFile);

                % Configure the expression used to read the timer
                readTimerExpression = '_mfc0(_CP0_COUNT, _CP0_COUNT_SELECT)';  %% Internal Core Timer

                this.setReadTimerExpression(readTimerExpression);
            end
        end
    end
end

