classdef ConnectivityConfig < rtw.connectivity.Config
    %CONNECTIVITYCONFIG is an example target connectivity configuration class

    %   Copyright 2007-2012 The MathWorks, Inc.

    methods
        function this = ConnectivityConfig(componentArgs)

            % A target application framework specifies additional source files and libraries
            % required for building the executable
            targetApplicationFramework = ...
                mchppil_SAMx.TargetApplicationFramework(componentArgs);

            % Filename extension for executable on the target system (e.g.
            % '.exe' for Windows or '' for Unix
            exeExtension = '.elf';

            % Create an instance of MakefileBuilder; this works in conjunction with your
            % template makefile to build the PIL executable
            builder = rtw.connectivity.MakefileBuilder(componentArgs, ...
                targetApplicationFramework, ...
                exeExtension);

            % Launcher
            launcher = mchppil_SAMx.Launcher(componentArgs, builder);

            % File extension for shared libraries (e.g. .dll on Windows)
            sharedLibExt=system_dependent('GetSharedLibExt');

            % Evaluate name of the rtIOStream shared library
            if ispc
                rtiostreamLib = ['rtiostreamserial' sharedLibExt];	 %rtiostreamserial.dll
            else
                rtiostreamLib = ['libmwrtiostreamserial' sharedLibExt];   %libmwrtiostreamserial.so
            end

            hostCommunicator = rtw.connectivity.RtIOStreamHostCommunicator(...
                componentArgs, ...
                launcher, ...
                rtiostreamLib);


            % For some targets it may be necessary to set a timeout value
            % for initial setup of the communications channel. For example,
            % the target processor may take a few seconds before it is
            % ready to open its side of the communications channel. If a
            % non-zero timeout value is set then the communicator will
            % repeatedly try to open the communications channel until the
            % timeout value is reached.
            hostCommunicator.setInitCommsTimeout(4);

            % Configure a timeout period for reading of data by the host
            % from the target. If no data is received with the specified
            % period an error will be thrown.
            timeoutReadDataSecs = 5;
            hostCommunicator.setTimeoutRecvSecs(timeoutReadDataSecs);

            % Set serial host port settings

            %COMPort = 'COM26';
            COMPort = mchp.prefs.getPIL_COMPort();  % 'COM1'
            if isempty(COMPort)
                error('COM Port not set for Processor In the Loop (PIL) simulation.');
            end
            BaudRate = mchp.prefs.getPIL_COMSpeed();		% 115200;

             disp(['COM port ' COMPort ' set with ' int2str(BaudRate) '.']);

            % see options in host file rtiostream_serial.c (C:\Program Files\MATLAB\R2021b\toolbox\coder\rtiostream\src\rtiostreamserial)
            % -port
            % -baud (see baud list for linux in rtiostream_serial.c )
            % -verbose 0 (default), 1, 2
            % -rtsDtrEnable
            % -rxIdleTimeout
            % -postOpenPause

            if isunix()
                %disp('Warning: Linux: DTR not enabled, might cause issues with USB virtual COM');
                rtIOStreamOpenArgs = {...
                    '-baud', int2str(BaudRate), ...
                    '-port', COMPort, ...            
                    '-postOpenPause','2'...       %% testing
                    };
            else
                rtIOStreamOpenArgs = {...
                    '-baud', int2str(BaudRate), ...
                    '-port', COMPort, ... %
                    '-rtsDtrEnable','1', ...                    
                    '-postOpenPause','2'...       %% testing
                    };                
            end

            hostCommunicator.setOpenRtIOStreamArgList(rtIOStreamOpenArgs);


            % call super class constructor to register components
            this@rtw.connectivity.Config(componentArgs,...
                builder,...
                launcher,...
                hostCommunicator);

            % Register hardware configuration if char is not 8 bits
            %RPmodif extendedHWConfig = my.ExtendedHardwareConfig;
            %RPmodif this.setExtendedHardwareConfig(extendedHWConfig);

            % Register timer functions
            timer = mchppil_SAMx.Timer;
            this.setTimer(timer);

            if 0
                % The timer API is changing so we need to check whether to use the
                % new or old style
                if mchppil_SAMx.ConnectivityConfig.isOldStyleTimerApi
                    % Register a timer if the execution profiling infrastructure is available. For
                    % PIL simulations, a file execProfile.mat is created in the pil
                    % sub-folder of the build directory. This file contains execution
                    % time measurements for the component that you are running in PIL
                    % simulation mode.
                    if ~isempty(rtw.connectivity.Timer)
                        timer = mchppil_SAMx.TimerOldStyle(targetApplicationFramework);
                        this.setTimer(timer);
                    end
                else
                    timer = mchppil_SAMx.Timer;
                    this.setTimer(timer);
                end
            end

        end
    end

    % From Arduino_ec
    methods (Static = true)
        function isOldStyle = isOldStyleTimerApi
            h = new_system;
            try
                get_param(h,'CodeExecutionProfiling');
                isOldStyle=false;
            catch exc
                if any(strcmp(exc.identifier, {'Simulink:SL_ParamUnknown', ...
                        'Simulink:Commands:ParamUnknown'}))
                    isOldStyle=true;
                else
                    rethrow(exc);
                end
            end
            close_system(h);
        end
    end



end

