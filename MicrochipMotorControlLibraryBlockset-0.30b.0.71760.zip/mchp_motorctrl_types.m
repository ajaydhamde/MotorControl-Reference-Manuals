function types = mchp_motorctrl_types(workspace)
	if ~exist('workspace','var')
		workspace = [];
	end
	types = struct();
	types.mchp_int16q15_t = fixdt(true, 16, 15);
	types.mchp_int32q31_t = fixdt(true, 32, 31);
	types.mchp_int16q11_t = fixdt(true, 16, 11);

	% begin struct mchp_MC_PISTATE_T
	B = Simulink.Bus();

	E = Simulink.BusElement();
	E.Name = 'integrator';
	E.DataType = types.mchp_int32q31_t.tostring();
	B.Elements(end+1) = E;

	E = Simulink.BusElement();
	E.Name = 'kp';
	E.DataType = types.mchp_int16q11_t.tostring();
	B.Elements(end+1) = E;

	E = Simulink.BusElement();
	E.Name = 'ki';
	E.DataType = types.mchp_int16q15_t.tostring();
	B.Elements(end+1) = E;

	E = Simulink.BusElement();
	E.Name = 'kc';
	E.DataType = types.mchp_int16q15_t.tostring();
	B.Elements(end+1) = E;

	E = Simulink.BusElement();
	E.Name = 'outMax';
	E.DataType = types.mchp_int16q15_t.tostring();
	B.Elements(end+1) = E;

	E = Simulink.BusElement();
	E.Name = 'outMin';
	E.DataType = types.mchp_int16q15_t.tostring();
	B.Elements(end+1) = E;
	B.HeaderFile = 'motor_control.h';
	types.mchp_MC_PISTATE_T = B;
	% end struct mchp_MC_PISTATE_T
	if ~isempty(workspace)
		assignin(workspace, 'mchp_MC_PISTATE_T', B); 
	end 
	