% MPLAB Device Blocks for Simulink
% Version 3.50.24 (R20xx) 15-Apr-2022
