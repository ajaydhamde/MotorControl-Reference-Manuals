function sfunc_dq2xy_CCASM(block)
% see http://www.mathworks.com/help/simulink/sfg/writing-level-2-matlab-s-functions.html
% http://www.mathworks.com/support/solutions/en/data/1-6EIW1S/index.html?solution=1-6EIW1S
% http://www.mathworks.com/help/releases/R2012a/toolbox/simulink/sfg/f7-67622.html#brgtux6
% http://www.mathworks.com/help/simulink/sfg/custom-data-types.html#bridxj6

  setup(block);
  
%endfunction

function setup(block)
  
  %% Register number of input and output ports
  block.NumInputPorts  = 2;
  block.NumOutputPorts = 1;

  %% Setup functional port properties to dynamically
  %% inherited.
  block.SetPreCompOutPortInfoToDynamic;

  % -------------------------------
  % Input ports
  % -------------------------------
  i = 0;
  
  % inptr MC_DQ_T dq
  % (fixdt(true, 16, 15), 2)  
  i = i + 1;
  id_fixpt = block.RegisterDataTypeFxpBinaryPoint(true, 16, 15, true);
  block.InputPort(i).DatatypeID  = id_fixpt;
  block.InputPort(i).DirectFeedthrough = true;
  block.InputPort(i).Dimensions        = 2;
  block.InputPort(i).Complexity  = 'Real';
  
  % inptr MC_SINCOS_T cs
  % (fixdt(true, 16, 15), 2)  
  i = i + 1;
  id_fixpt = block.RegisterDataTypeFxpBinaryPoint(true, 16, 15, true);
  block.InputPort(i).DatatypeID  = id_fixpt;
  block.InputPort(i).DirectFeedthrough = true;
  block.InputPort(i).Dimensions        = 2;
  block.InputPort(i).Complexity  = 'Real';

  % -------------------------------
  % Output ports
  % -------------------------------
  i = 0;  
  
  % outptr MC_ALPHABETA_T alphabeta
  % (fixdt(true, 16, 15), 2)  
  i = i + 1;
  id_fixpt = block.RegisterDataTypeFxpBinaryPoint(true, 16, 15, true);
  block.OutputPort(i).DatatypeID  = id_fixpt;
  block.OutputPort(i).Dimensions        = 2;
  block.OutputPort(i).Complexity  = 'Real';

  %% Set block sample time to inherited
  block.SampleTimes = [-1 0];
  
  %% Set the block simStateCompliance to default (i.e., same as a built-in block)
  block.SimStateCompliance = 'DefaultSimState';

  %% Run accelerator on TLC
  block.SetAccelRunOnTLC(true);
  
  %% Register methods
  block.NumDialogPrms = 0;
  
  block.RegBlockMethod('Outputs',                 @Output);  
  block.RegBlockMethod('PostPropagationSetup',    @DoPostPropSetup);    
  block.RegBlockMethod('CheckParameters',         @CheckParam);

  
%endfunction

function Output(block)
  % just a dummy function  
%endfunction

function DoPostPropSetup(block)
  % http://www.mathworks.com/matlabcentral/answers/45041: 
  % here's how you name parameters

%endfunction

function CheckParam(block)
%endfunction