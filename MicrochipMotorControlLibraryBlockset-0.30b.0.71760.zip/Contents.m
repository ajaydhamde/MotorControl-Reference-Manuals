% Microchip Motor Control Library Blockset
% Version 0.30b.0.71760 (R2013b) 19-Mar-2015
