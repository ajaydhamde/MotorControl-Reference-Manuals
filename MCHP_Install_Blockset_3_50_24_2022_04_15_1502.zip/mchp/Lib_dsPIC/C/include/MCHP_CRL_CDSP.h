/* Auto Generated file. Author: Lubin Kerhuel, Microchip Technology Inc */
  
#ifndef _MCHP_CRL_CDSP_
#define _MCHP_CRL_CDSP_

    extern int MCHP_DSP_atan2Cordic_Inline( int u2,  int u1);
    extern int MCHP_DSP_atan2Taylor_Inline( int u1,  int u2);
	extern int MCHP_DSP_atan2Horner_Inline( int u1,  int u2);
	
#endif
