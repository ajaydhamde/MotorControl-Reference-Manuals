

extern unsigned int  MCHP_ProfilingTimer();

