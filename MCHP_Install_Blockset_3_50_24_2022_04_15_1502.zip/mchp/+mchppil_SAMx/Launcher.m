classdef Launcher < rtw.connectivity.Launcher
    %LAUNCHER is an example target connectivity configuration class

    %   Copyright 2007-2012 The MathWorks, Inc.

    properties
        % For the host-based example, additional arguments may be provided when the
        % executable is launched as a separate process on the host. For example it may
        % be required to specify a TCP/IP port number.
        ArgString= '';

        % For the host-based example, it is necessary to
        % keep track of the process ID of the executable
        % so that this process can be killed when no longer
        % required
        ExePid = '';

        % For the host-based example, it is necessary to keep track of a temporary file
        % created by the process launcher so that it can be deleted when the
        % process is terminated
        TempFile = '';

        MCHP_Time = [];


    end

    methods
        % constructor
        function this = Launcher(componentArgs, builder)
            narginchk(2, 2);
            % call super class constructor
            this@rtw.connectivity.Launcher(componentArgs, builder);
            this.MCHP_Time = [];
                        
            if ismethod(this,'setExe')
                exe = [componentArgs.getComponentCodePath filesep componentArgs.getComponentCodeName '.elf'];
                this.setExe(exe);
            end
        end

        % destructor
        function delete(this) %#ok

            % This method is called when an instance of this class is cleared from memory,
            % e.g. when the associated Simulink model is closed. You can use
            % this destructor method to close down any processes, e.g. an IDE or
            % debugger that was originally started by this class. If the
            % stopApplication method already performs this housekeeping at the
            % end of each on-target simulation run then it is not necessary to
            % insert any code in this destructor method. However, if the IDE or
            % debugger may be left open between successive on-target simulation
            % runs then it is recommended to insert code here to terminate that
            % application.

        end

        function setArgString(this, argString)
            % Specify command line arguments; for example, you may need to provide a TCP/IP
            % port number to override the default port number. If your Launcher
            % does not require any dynamic parameter configuration then this
            % method may not be required.
            disp('EXECUTING METHOD SETARGSTRING')
            stack = dbstack;
            disp(['SETARGSTRING called from line '...
                int2str(stack(2).line) ' of ' ...
                stack(2).file ])

            this.ArgString = argString;
        end

        % Start the application
        function startApplication(this)
            % get name of the executable file
            if ~ismethod(this,'getExe')
            	exe = this.getBuilder.getApplicationExecutable; %% deprecated, provide error, missing builtInfo.mat with recent matlab release!
            else
            	exe = this.getExe;  % Jon Fielder  (MW 2020/25/11) for recent releases  
            	% get 'C:\M91449\MCHP_Blockset\Developpements\2019_08_dsPIC_CH_DualCore\dsPIC33CK512MP508_CuriosityBoard.exe'
            	% trick below to fix wrong name & path
% The filename is set in the launcher constructor  (trick to fix issue with R2020b with External mode)              
 	            [p f ext] = fileparts(exe);
                 makefile = [exe(1:end-3) 'mk'];
                 
                 if ~exist(exe,'file')  % file is in the root folder with SAMx chips
                     p = fileparts(p);
                     exe = [p filesep f ext];
                 end
                     
 	            if strcmp(ext,'.exe')
                    %pX = mchp.prefs.getFolderNameExtension;
 	                %exe = [p filesep f pX filesep f '.elf'];
                    exe = [p filesep f '.elf'];
 	                if ~exist(exe,'FILE')
 	                	if exist([exe(1:end-3) 'cof'],'file')
 	                		exe = [exe(1:end-3) 'cof'];
 	                	else
 	                		warning(['Launcher: File ' exe ' not found.']);
 	                	end
 					end
 	            end
            end

           %% if exist([exe(1:end-3) 'hex'],'file')
           %%     exe = [exe(1:end-3) 'hex']; % prefere hex file if exist
           %%  end
            PIC_REF = '';
            %try
           
            fid = fopen(makefile,'r');
            if fid == -1                
                warning(['Makefile ' makefile ' not found. Programming might not work.']);                
            else
                s = char(fread(fid)');
                fclose(fid);
                s = regexprep(s,'^.*echo.*$','','dotexceptnewline','lineanchors'); % Remove anything in echo
                PIC_REF = regexp(s,'CHIP\_REF\s+=\s+(\S+)','tokens');                
                if isempty(PIC_REF)
                    PIC_REF = regexp(s,'PIC\_REF\s+=\s+(\S+)','tokens');    
                end
                PIC_REF = PIC_REF{1}{1};
            end
            %end

            %exe = 'cmd';
            %this.ArgString = '';

            disp('Flash Chip')
            % launch
            %[this.ExePid, this.TempFile] = ...
            %   rtw.connectivity.Utils.launchProcess(...
            %       exe, ...
            %       this.ArgString);

            switch mchp.prefs.getPIL_Programmer()
                case 1 % Matlab programmer
                    picflash(PIC_REF,exe);
                    % Pause to ensure that server-side of TCP/IP connection
                    % is established and ready to accept a client connection
                    delay = mchp.prefs.getPIL_Delay();
                    disp(['Pause ' num2str(delay) 's for Target to start before starting simulation...']);
                    if delay == inf
                        button = questdlg('press continue to start Simulation.','PIL Wait before starting simulation','continue','continue');
                    else
                        pause(delay);
                    end

                case 2	% Third part programmer
                    button = questdlg('Program the chip and press continue to start Simulation.','PIL Wait before starting simulation','continue','continue');
            end


            disp('Starting PIL simulation');
            this.MCHP_Time = tic;

            % if ~rtw.connectivity.Utils.isAlive(this.ExePid)
            % disp('')
            % disp(['Process is not alive, displaying contents '...
            % 'of log file:'])
            % disp('')
            % type(this.TempFile)
            % disp('')
            % error(['Failed to start process with PID = '...
            % num2str(this.ExePid) ' using arguments '...
            % this.ArgString '. '...
            % 'The process may have failed to start '...
            % 'correctly, for example, because an existing '...
            % 'process is already bound to the same TCP/IP '...
            % 'port. Check that there are no other '...
            % 'processes running on this machine that are '...
            % 'bound to this TCP/IP port.'])
            % end
            % disp(['Started new process, pid = ' ...
            % int2str(this.ExePid) ])

        end

        % Stop the application
        function stopApplication(this)
            timeElapsed = toc(this.MCHP_Time);
            disp(['PIL simulation terminated in ' num2str(timeElapsed) 's']);
            clear mex;  % enable the capability to re-compile the {model}_psf.mexXX file
            % if ~isempty(this.ExePid)
            % rtw.connectivity.Utils.killProcess(this.ExePid, ...
            % this.TempFile);
            % disp(['Terminated process, pid = ' int2str(this.ExePid)]);
            % end
            % this.ExePid = '';

        end

%   Optionally, you can provide the following method:
%
%     GETAPPLICATIONSTATUS - called to detect the current status of the target application.
%                            When you make a subclass of LAUNCHER, you can provide an
%                            implementation of this method. 
%                            The expected return values are:
%                            - rtw.connectivity.LauncherApplicationStatus.UNKNOWN
%                            - rtw.connectivity.LauncherApplicationStatus.NOT_RUNNING
%                            - rtw.connectivity.LauncherApplicationStatus.RUNNING
%                            If you do not implement this method, the default return value is
%                            rtw.connectivity.LauncherApplicationStatus.UNKNOWN
%        function status = getApplicationStatus(~)
%            status = rtw.connectivity.LauncherApplicationStatus.RUNNING;
%        end

    end
end
