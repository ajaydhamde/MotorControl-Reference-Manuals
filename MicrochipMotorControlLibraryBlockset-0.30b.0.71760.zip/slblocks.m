function blkStruct = slblocks

libraryFile = 'MicrochipMotorControlLibraryBlockset';

% Name of the top-level library which will show up in the Simulink Library Browser.
blkStruct.Name = libraryFile;

% The function that will be called when the user double-clicks on
% this icon.
%
%blkStruct.OpenFcn = 'MotorLibrary';

% The argument to be set as the Mask Display for the subsystem.  
blkStruct.MaskDisplay = '';

Browser(1).Library = libraryFile;
registeredTrademark = sprintf('\x00ae');
Browser(1).Name    = sprintf('Microchip%s Motor Control Library Blockset', registeredTrademark);
Browser(1).IsFlat  = 1;% Is this library "flat" (i.e. no subsystems)?

blkStruct.Browser = Browser;
% End of slblocks.m