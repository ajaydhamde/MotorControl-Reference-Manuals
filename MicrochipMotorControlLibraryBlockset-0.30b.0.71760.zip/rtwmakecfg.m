function makeInfo = rtwmakecfg()

LibDir = fullfile(pwd, 'lib');
    
makeInfo.includePath = { LibDir };
makeInfo.sourcePath = {};
makeInfo.sources  = {};
makeInfo.linkLibsObjs = {};
makeInfo.precompile = 0;

mdlroot = bdroot(gcs);

arch3 = MCHP_API.RTWGenSettings_Read(mdlroot,'arch3');
switch arch3
    % Leave off the .a at the end; whichlib is the argument passed to the linker.
    case '33E'
        whichlib = 'libmotor_control_dspic33e-elf';
    case '33F'
        whichlib = 'libmotor_control_dspic33f-elf';
    otherwise 
        whichlib = '';
end

if ~isempty(whichlib)		
	makeInfo.library(1).Name     = whichlib;
	makeInfo.library(1).Location = LibDir;
	makeInfo.library(1).Modules  = {};
end

end

