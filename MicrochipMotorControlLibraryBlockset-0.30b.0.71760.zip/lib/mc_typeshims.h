#define mchp_MC_PISTATE_T MC_PISTATE_T
