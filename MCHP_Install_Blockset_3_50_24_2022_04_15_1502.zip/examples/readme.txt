Examples might not compile if they are used from the program file folder due to permissions issues. They should be copied in a working folder first.

Examples are only to demonstrate how to use the blockset. They are not a reference design for any of the sensor used here.

For any question, please go on the Microchip forum: http://www.microchip.com/forums/f192.aspx
