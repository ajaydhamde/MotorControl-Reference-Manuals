classdef MicrochipMotorControlUtil
% A utility class containing helper functions
    methods(Static)
        function result = showCodeGenSelect(root, shown)
            % Show/hide selection box for code generation type
            if ~exist('shown','var')
                shown = true;
            end
            if shown
                shownstring = 'on';
            else
                shownstring = 'off';
            end
            result = do_findFlexGenBlocks(root);
            for i = 1:length(result)
                blk = result(i).path;
                masknames = get_param(blk, 'MaskNames');
                v = get_param(blk,'MaskVisibilities');
                for j = 1:length(masknames)
                    if strcmp(masknames{j},'cgentype')
                        v{j} = shownstring;
                    end
                end
                set_param(blk,'MaskVisibilities',v);                
            end
        end
        function result = findFlexGenBlocks(root)
            % Find all blocks that have code generation / simulation type
            % selection, starting at the block specified by the "root"
            % argument.
            %
            % Returns an array of structures with these elements:
            %   - path        Simulink path to block
            %   - cgentype    code generation type
            %   - simtype     simulation type
            result = do_findFlexGenBlocks(root);
            for i = 1:length(result)
                result(i).cgentype = get_param(result(i).path, 'cgentype');
                result(i).simtype = get_param(result(i).path, 'simtype');
            end
        end
        function result = setFlexGenType(root, whichopt, whichtype)
            % Set code generation or simulation type for blocks
            % 
            % All blocks below the specified "root" object will be set
            % to have a given code generation or simulation type.
            %
            % root: path below which blocks are selected
            % whichopt: 'cgentype' for code generation, 'simtype' for
            %   simulation
            % whichtype: a valid type for code generation or simulation
            %   e.g. 'Pure Simulink', 'C', or 'CCASM'
            %
            % Returns a list of blocks that were changed.
            if ~strcmp(whichopt,'cgentype') && ~strcmp(whichopt,'simtype')
                error('setFlexGenType','whichopt must be cgentype for code generation or simtype for simulation');
            end
            result = {};
            blocks = do_findFlexGenBlocks(root);
            for i = 1:length(blocks)
                cgopts = blocks(i).(whichopt).Enum;
                for j = 1:length(cgopts)
                    if strcmp(cgopts{j},whichtype)
                        set_param(blocks(i).path, whichopt, whichtype);
                        result{end+1} = blocks(i).path;
                    end
                end
            end                
        end
        function walkSimObject(root,f)
            walkobj(root,f)
        end
        function root = path()
            root = fileparts(mfilename('fullpath'));
        end
    end
end

function walkobj(root,f)
if f(root)
    blocks = getp(root,'Blocks');
    for i = 1:length(blocks)
        walkobj([root '/' blocks{i}], f);
    end
end
end

function list = do_findFlexGenBlocks(root)
list = struct([]);
    function b = helper(path)
        b = true;
        v = getp(path,'ReferenceBlock');
        if startswith(v,'MicrochipMotorControlLibraryBlockset/')
            S = get_param(path,'DialogParameters');
            if isfield(S,'cgentype') && isfield(S,'simtype')
                b = false;
                list(end+1).path = path;
                list(end).cgentype = S.cgentype;
                list(end).simtype = S.simtype;
            end
        end
    end
walkobj(root,@helper);
end

function b = startswith(s1,s2)
    b = strncmp(s1,s2,length(s2));
end

function v = getp(path, param)
try
    v = get_param(path,param);
catch
    v = [];
end
end
